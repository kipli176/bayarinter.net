# 💳 Billing Mikrotik (Flask Version)

Sistem billing sederhana untuk pelanggan internet berbasis Mikrotik dan Flask. Mendukung fitur login admin, manajemen pelanggan, generate akun Mikrotik, dan pelacakan tagihan bulanan.

---

## 🚀 Fitur Utama

- Login, register, verifikasi akun admin
- Sinkronisasi pelanggan dari Mikrotik
- Tambah/edit/hapus pelanggan
- Manajemen tagihan bulanan
- Cetak struk pembayaran
- Integrasi dengan RouterOS API (via `routeros_api`)

---

## 🧱 Struktur Proyek

```
billing-mikrotik/
│
├── app.py                  # Entry point aplikasi Flask
├── billing-init.py         # Inisialisasi database SQLite
├── db.py                   # Fungsi koneksi database
├── mikrotik_helper.py      # Koneksi ke Mikrotik (RouterOS API)
├── mikrotik_services.py    # Fungsi wrapper Mikrotik
├── utils.py                # Fungsi utilitas umum
│
├── templates/              # File HTML (Jinja2)
│
├── routes/                 # Modularisasi routing Flask
│   ├── __init__.py
│   ├── auth_routes.py
│   ├── admin_routes.py
│   ├── pelanggan_routes.py
│   └── tagihan_routes.py
│
└── requirements.txt        # Daftar dependensi
```

---

## ⚙️ Instalasi

1. **Clone repo atau extract ZIP**
2. **Buat virtual environment (opsional tapi disarankan):**
   ```bash
   python -m venv venv
   source venv/bin/activate  # atau venv\Scripts\activate di Windows
   ```

3. **Install dependensi:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Jalankan aplikasi:**
   ```bash
   python app.py
   ```

   Jika file database belum ada, maka `billing-init.py` akan otomatis dijalankan.

---

## 🔐 Default Admin & Database

- Database menggunakan SQLite: `langganan.sqlite3`
- Tidak ada akun default. Silakan daftar melalui halaman `/register`

---

## 🌐 Koneksi Mikrotik

- File `mikrotik_helper.py` mengandung kredensial koneksi Mikrotik:
  ```python
  MIKROTIK_HOST = '203.xxx.xxx.xxx'
  MIKROTIK_USER = 'admin'
  MIKROTIK_PASS = 'rahasia'
  MIKROTIK_PORT = 8728
  ```
- Gantilah sesuai router Mikrotik milik Anda.

---

## 📋 Catatan Tambahan

- Gunakan Mikrotik yang sudah mengaktifkan API service
- Gunakan HTTPS jika akan dihosting publik (bukan hanya untuk pengujian lokal)
- Untuk fitur OTP/email/verifikasi lanjutan, perlu integrasi tambahan (SMTP, SMS Gateway, dsb)

---

## 🧑‍💻 Kontribusi

Pull request dan kontribusi lain sangat terbuka — pastikan kode terstruktur dan mengikuti gaya proyek modular ini.

---

## 📝 Lisensi

Proyek ini bersifat bebas digunakan dan dimodifikasi. Sertakan atribusi bila digunakan untuk produksi.
