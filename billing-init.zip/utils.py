import requests

def kirim_tagihan(no_hp, nama, jumlah_tagihan, bulan):
    WA_API_URL = "http://194.163.184.129:3001/send-message"
    WA_HEADERS = {"Content-Type": "application/json"}

    # Format rupiah
    rupiah = f"Rp {jumlah_tagihan:,.0f}".replace(",", ".")

    message = (
        f"📢 Halo {nama},\n\n"
        f"Ini adalah pengingat untuk tagihan internet Anda bulan *{bulan}*.\n"
        f"Jumlah tagihan: *{rupiah}*\n\n"
        f"Silakan lakukan pembayaran tepat waktu untuk menghindari gangguan layanan.\n\n"
        f"Terima kasih.\n(Admin Billing)"
    )

    payload = {"number": no_hp, "message": message}
    try:
        response = requests.post(WA_API_URL, headers=WA_HEADERS, json=payload, timeout=10)
        return response.ok
    except:
        return False
