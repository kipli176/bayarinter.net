from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from db import get_db
from datetime import datetime, date, timedelta
from utils import kirim_tagihan 

tagihan_bp = Blueprint('tagihan', __name__)

def admin_login_required():
    if 'admin_id' not in session:
        flash('Silakan login terlebih dahulu.', 'error')
        return False
    return True

@tagihan_bp.route('/tagihan')
def tagihan():
    if not admin_login_required():
        return redirect(url_for('auth.login'))

    bulan = request.args.get('bulan', date.today().replace(day=1).strftime('%Y-%m-%d'))
    id_admin = session['admin_id']

    today = date.today()
    bulan_options = []
    for i in range(12):
        b = today.replace(day=1) - timedelta(days=30 * i)
        bulan_options.append(b.strftime('%Y-%m-01'))

    conn = get_db()
    c = conn.cursor()

    c.execute('''
        SELECT 
            p.id AS id_pelanggan,
            p.nama,
            p.paket,
            p.status AS status_pelanggan_terkini,
            t.id AS id_tagihan,
            t.jumlah_tagihan,
            t.status AS status_tagihan,
            IFNULL((SELECT SUM(jumlah_bayar) FROM pembayaran pb WHERE pb.id_tagihan = t.id), 0) AS total_bayar,
            (t.jumlah_tagihan - IFNULL((SELECT SUM(jumlah_bayar) FROM pembayaran pb WHERE pb.id_tagihan = t.id), 0)) AS sisa_tagihan,
            t.petugas
        FROM pelanggan p
        LEFT JOIN tagihan t ON p.id = t.id_pelanggan AND t.bulan = ?
        WHERE p.id_admin = ?
        ORDER BY p.nama
    ''', (bulan, id_admin))

    rows = c.fetchall()
    conn.close()

    data = []
    for row in rows:
        row_dict = dict(row)
        if row_dict['id_tagihan'] is None:
            row_dict['status_pembayaran'] = 'tidak ada tagihan'
            row_dict['sisa_tagihan'] = 0
        else:
            total_bayar = row_dict['total_bayar']
            jumlah_tagihan = row_dict['jumlah_tagihan']
            if total_bayar == 0 and jumlah_tagihan > 0:
                row_dict['status_pembayaran'] = 'belum lunas'
            elif 0 < total_bayar < jumlah_tagihan:
                row_dict['status_pembayaran'] = 'cicil'
            elif total_bayar >= jumlah_tagihan:
                row_dict['status_pembayaran'] = 'lunas'
            else:
                row_dict['status_pembayaran'] = 'lunas'
        data.append(row_dict)

    return render_template('tagihan.html', data=data, bulan=bulan, bulan_options=bulan_options)

@tagihan_bp.route('/tagihan/bayar/<int:id_tagihan>', methods=['POST'])
def bayar(id_tagihan):
    if not admin_login_required():
        return redirect(url_for('auth.login'))

    conn = get_db()
    c = conn.cursor()

    # Ambil data tagihan dan pelanggan
    c.execute('''
        SELECT t.id, t.jumlah_tagihan, t.status, p.nama
        FROM tagihan t
        JOIN pelanggan p ON t.id_pelanggan = p.id
        WHERE t.id = ?
    ''', (id_tagihan,))
    tagihan = c.fetchone()

    if tagihan is None:
        conn.close()
        return "Tagihan tidak ditemukan", 404

    if request.method == 'POST':
        try:
            jumlah_bayar = float(request.form['jumlah_bayar'])
            if jumlah_bayar <= 0:
                flash('Jumlah bayar harus lebih dari 0', 'error')
                return redirect(url_for('tagihan.bayar', id_tagihan=id_tagihan))

            tanggal_bayar = datetime.now().strftime('%Y-%m-%d')

            # Insert pembayaran baru
            c.execute('''
                INSERT INTO pembayaran (id_tagihan, tanggal_bayar, jumlah_bayar)
                VALUES (?, ?, ?)
            ''', (id_tagihan, tanggal_bayar, jumlah_bayar))

            # Hitung total bayar sampai saat ini
            c.execute('''
                SELECT SUM(jumlah_bayar) as total_bayar
                FROM pembayaran
                WHERE id_tagihan = ?
            ''', (id_tagihan,))
            total_bayar = c.fetchone()['total_bayar'] or 0

            # Update status tagihan berdasarkan total bayar
            status_bayar = 'belum lunas'
            if total_bayar >= tagihan['jumlah_tagihan']:
                status_bayar = 'lunas'
            elif total_bayar > 0:
                status_bayar = 'cicil'

            c.execute('UPDATE tagihan SET status = ? WHERE id = ?', (status_bayar, id_tagihan))
            conn.commit()
            flash(f'Pembayaran berhasil dicatat, status tagihan: {status_bayar}', 'success')
            return redirect(url_for('tagihan.tagihan'))

        except ValueError:
            flash('Input jumlah bayar tidak valid', 'error')
            return redirect(url_for('tagihan.bayar', id_tagihan=id_tagihan))

    conn.close()
    return render_template('bayar.html', tagihan=tagihan)

@tagihan_bp.route('/tagihan/cetak/<int:id_tagihan>')
def cetak_pembayaran(id_tagihan):
    if not admin_login_required():
        return redirect(url_for('auth.login'))

    conn = get_db()
    c = conn.cursor()

    # Ambil data pembayaran & pelanggan
    c.execute('''
        SELECT 
            p.nama, p.alamat, p.no_hp, p.petugas,
            t.bulan, t.jumlah_tagihan, t.status,
            (SELECT SUM(jumlah_bayar) FROM pembayaran WHERE id_tagihan = t.id) AS total_bayar,
            t.petugas
        FROM tagihan t
        JOIN pelanggan p ON t.id_pelanggan = p.id
        WHERE t.id = ? AND p.id_admin = ?
    ''', (id_tagihan, session['admin_id']))
    data = c.fetchone()

    if not data:
        flash('Data pembayaran tidak ditemukan atau bukan milik Anda.', 'error')
        return redirect(url_for('tagihan.tagihan'))

    # Ambil daftar pembayaran
    c.execute('SELECT tanggal_bayar, jumlah_bayar FROM pembayaran WHERE id_tagihan = ? ORDER BY tanggal_bayar', (id_tagihan,))
    riwayat = c.fetchall()
    conn.close()

    return render_template('cetak_struk.html', data=data, riwayat=riwayat)

 
@tagihan_bp.route('/tagihan/kirim-notifikasi', methods=['POST'])
def kirim_notifikasi():
    if not session.get("admin_id"):
        return redirect(url_for("auth.login"))

    id_tagihan = request.form.get("id_tagihan")

    conn = get_db()
    tagihan = conn.execute("""
        SELECT 
            t.id AS id_tagihan,
            t.jumlah_tagihan,
            t.bulan,
            p.nama,
            p.no_hp
        FROM tagihan t
        JOIN pelanggan p ON p.id = t.id_pelanggan
        WHERE t.id = ?
    """, (id_tagihan,)).fetchone()

    if not tagihan:
        flash("❌ Data tagihan tidak ditemukan", "error")
        return redirect(url_for("tagihan.tagihan"))

    if not tagihan["no_hp"]:
        flash("❌ Nomor HP pelanggan tidak tersedia", "error")
        return redirect(url_for("tagihan.tagihan"))

    if tagihan["jumlah_tagihan"] is None or tagihan["jumlah_tagihan"] <= 0:
        flash("❌ Tidak ada jumlah tagihan yang valid untuk dikirim", "error")
        return redirect(url_for("tagihan.tagihan"))

    try:
        bulan_obj = datetime.strptime(tagihan["bulan"], "%Y-%m-%d")
        bulan_format = bulan_obj.strftime("%B %Y")  # Contoh: "Desember 2025"

        success = kirim_tagihan(
            no_hp=tagihan["no_hp"],
            nama=tagihan["nama"],
            jumlah_tagihan=tagihan["jumlah_tagihan"],
            bulan=bulan_format
        )
        if success:
            flash(f"✅ Notifikasi berhasil dikirim ke {tagihan['nama']}", "success")
        else:
            flash(f"❌ Gagal mengirim notifikasi ke {tagihan['nama']}", "error")
    except Exception as e:
        flash(f"⚠️ Terjadi kesalahan: {str(e)}", "error")

    return redirect(url_for("tagihan.tagihan", bulan=tagihan["bulan"]))