from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from db import get_db
from mikrotik_helper import check_active_bulk, delete_secret_remote, add_secret_remote, connect_remote, get_profiles_remote
import re

pelanggan_bp = Blueprint('pelanggan', __name__)

def admin_login_required():
    if 'admin_id' not in session:
        flash('Silakan login terlebih dahulu.', 'error')
        return False
    return True

@pelanggan_bp.route('/sinkron-pelanggan', methods=['POST'])
def sinkron_pelanggan():
    if not admin_login_required():
        return redirect(url_for('auth.login'))

    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT ip_address, ppp_username, ppp_password FROM admin WHERE id_admin = ?', (session['admin_id'],))
    admin_data = c.fetchone()

    if not admin_data or not admin_data['ip_address']:
        flash('IP address Mikrotik tidak ditemukan atau admin belum aktif.', 'error')
        conn.close()
        return redirect(url_for('pelanggan.pelanggan'))

    try:
        api = connect_remote(admin_data['ip_address'], admin_data['ppp_username'], admin_data['ppp_password'])

        active_users = api.get_resource('/ppp/active').get()
        active_names = {u['name'] for u in active_users if 'name' in u}
        secrets = api.get_resource('/ppp/secret').get()

        synced = 0
        for secret in secrets:
            name = secret.get('name')
            if name not in active_names:
                continue

            c.execute('SELECT COUNT(*) FROM pelanggan WHERE ppp_username = ? AND id_admin = ?', (name, session['admin_id']))
            if c.fetchone()[0] == 0:
                password = secret.get('password', '')
                profile = secret.get('profile', '')
                c.execute('''
                    INSERT INTO pelanggan (nama, ppp_username, ppp_password, paket, harga_bulanan, status, id_admin)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (name, name, password, profile, '1.00', 'aktif', session['admin_id']))
                synced += 1

        conn.commit()
        flash(f'{synced} pelanggan aktif berhasil diimpor dari Mikrotik.', 'success')

    except Exception as e:
        flash(f'Gagal sinkronisasi: {e}', 'error')

    finally:
        conn.close()

    return redirect(url_for('pelanggan.pelanggan'))


@pelanggan_bp.route('/pelanggan')
def pelanggan():
    if not admin_login_required():
        return redirect(url_for('auth.login'))

    # Ambil data pelanggan milik admin dari DB
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM pelanggan WHERE id_admin = ?", (session['admin_id'],))
    data_pelanggan = c.fetchall()

    # Ambil info koneksi Mikrotik dari admin
    c.execute("SELECT ip_address, ppp_username, ppp_password FROM admin WHERE id_admin = ?", (session['admin_id'],))
    admin_data = c.fetchone()
    conn.close()

    status_koneksi = {}
    username_list = [p['ppp_username'] for p in data_pelanggan]

    if not admin_data or not admin_data['ip_address']:
        flash('Admin belum mengatur koneksi Mikrotik.', 'error')
        # Semua dianggap offline
        status_koneksi = {u: 'offline' for u in username_list}
    else:
        try:
            api = connect_remote(
                admin_data['ip_address'],
                admin_data['ppp_username'],
                admin_data['ppp_password']
            )

            # Cek koneksi semua user sekaligus (efisien)
            status_koneksi = check_active_bulk(api, username_list)

        except Exception as e:
            flash(f'Gagal koneksi ke Mikrotik: {e}', 'error')
            status_koneksi = {u: 'offline' for u in username_list}

    return render_template(
        'pelanggan.html',
        data=data_pelanggan,
        status_koneksi=status_koneksi
    )



@pelanggan_bp.route('/pelanggan/tambah', methods=['GET', 'POST'])
def tambah_pelanggan():
    if not admin_login_required():
        return redirect(url_for('auth.login'))

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT ip_address, ppp_username, ppp_password FROM admin WHERE id_admin = ?", (session['admin_id'],))
    admin_data = c.fetchone()
    conn.close()

    if not admin_data or not admin_data['ip_address']:
        flash('Admin belum mengatur koneksi Mikrotik.', 'error')
        return redirect(url_for('pelanggan.tambah_pelanggan'))

    if request.method == 'POST':
        # Ambil data dari form
        nama = request.form['nama']
        alamat = request.form['alamat']
        no_hp = request.form['no_hp']
        paket = request.form['paket']
        harga = float(request.form['harga_bulanan'])
        ppp_user = request.form['ppp_username']
        ppp_pass = request.form['ppp_password']
        petugas = request.form['petugas']
        status = request.form['status']
        tgl_pasang = request.form['tgl_pasang']
        profil = request.form['paket']

        try:
            # Koneksi ke Mikrotik admin
            api = connect_remote(
                admin_data['ip_address'],
                admin_data['ppp_username'],
                admin_data['ppp_password']
            )

            # Komentar detail pelanggan
            comment = f"Nama: {nama} | HP: {no_hp} | Paket: {paket} | Pasang: {tgl_pasang}"

            # Coba tambah secret, gagal jika sudah ada
            add_secret_remote(
                api,
                name=ppp_user,
                password=ppp_pass,
                comment=comment,
                profile=profil,
                service='pppoe'
            )

            # Tambahkan ke database
            conn = get_db()
            c = conn.cursor()
            c.execute('''
                INSERT INTO pelanggan 
                (id_admin, nama, alamat, no_hp, paket, harga_bulanan, 
                 ppp_username, ppp_password, status, tgl_pasang, petugas)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                session['admin_id'], nama, alamat, no_hp, paket,
                harga, ppp_user, ppp_pass, status, tgl_pasang, petugas
            ))
            conn.commit()
            conn.close()

        except Exception as e:
            # Jika gagal tambah secret, batalkan
            flash(f'Gagal menambahkan pelanggan: {e}', 'error')
            return redirect(url_for('pelanggan.tambah_pelanggan'))

        flash('Pelanggan dan user Mikrotik berhasil ditambahkan.', 'success')
        return redirect(url_for('pelanggan.pelanggan'))

    # GET: render form dan ambil daftar profil
    try:
        api = connect_remote(
            admin_data['ip_address'],
            admin_data['ppp_username'],
            admin_data['ppp_password']
        )
        profil_list = get_profiles_remote(api)
    except Exception as e:
        profil_list = []
        flash(f'Gagal mengambil profil dari Mikrotik: {e}', 'error')

    return render_template('tambah_pelanggan.html', profil_list=profil_list)

@pelanggan_bp.route('/pelanggan/edit/<int:id>', methods=['GET', 'POST'])
def edit_pelanggan(id):
    if not admin_login_required():
        return redirect(url_for('auth.login'))

    conn = get_db()
    c = conn.cursor()

    # Ambil data pelanggan
    c.execute("SELECT * FROM pelanggan WHERE id = ? AND id_admin = ?", (id, session['admin_id']))
    pelanggan_data = c.fetchone()

    if not pelanggan_data:
        conn.close()
        flash('Pelanggan tidak ditemukan.', 'error')
        return redirect(url_for('pelanggan.pelanggan'))

    # Ambil info Mikrotik admin
    c.execute("SELECT ip_address, ppp_username, ppp_password FROM admin WHERE id_admin = ?", (session['admin_id'],))
    admin_data = c.fetchone()
    conn.close()

    if not admin_data or not admin_data['ip_address']:
        flash('Admin belum mengatur koneksi Mikrotik.', 'error')
        return redirect(url_for('pelanggan.pelanggan'))

    if request.method == 'POST':
        # Ambil data baru dari form
        nama = request.form['nama']
        alamat = request.form['alamat']
        no_hp = request.form['no_hp']
        paket = request.form['paket']
        harga_bulanan = float(request.form['harga_bulanan'])
        ppp_username_new = request.form['ppp_username']
        ppp_password_new = request.form['ppp_password']
        petugas = request.form['petugas']
        status = request.form['status']
        tgl_pasang = request.form['tgl_pasang']
        profil = request.form['paket']

        try:
            api = connect_remote(
                admin_data['ip_address'],
                admin_data['ppp_username'],
                admin_data['ppp_password']
            )

            # Jika username berubah, hapus secret lama
            if ppp_username_new != pelanggan_data['ppp_username']:
                delete_secret_remote(api, pelanggan_data['ppp_username'])

            # Buat comment baru
            comment = f"Nama: {nama} | HP: {no_hp} | Paket: {paket} | Pasang: {tgl_pasang}"

            # Tambahkan secret baru (baik ganti user/pass atau tidak)
            delete_secret_remote(api, ppp_username_new)  # aman, hanya jika ada
            add_secret_remote(api, name=ppp_username_new, password=ppp_password_new, comment=comment, profile=profil, service='pppoe')

            # Update ke database
            conn = get_db()
            c = conn.cursor()
            c.execute('''
                UPDATE pelanggan SET
                    nama = ?, alamat = ?, no_hp = ?, paket = ?, harga_bulanan = ?,
                    ppp_username = ?, ppp_password = ?, status = ?, tgl_pasang = ?, petugas = ?
                WHERE id = ? AND id_admin = ?
            ''', (
                nama, alamat, no_hp, paket, harga_bulanan,
                ppp_username_new, ppp_password_new, status, tgl_pasang, petugas,
                id, session['admin_id']
            ))
            conn.commit()
            conn.close()

        except Exception as e:
            flash(f'Gagal memperbarui pelanggan: {e}', 'error')
            return redirect(url_for('pelanggan.edit_pelanggan', id=id))

        flash('Data pelanggan dan Mikrotik berhasil diperbarui.', 'success')
        return redirect(url_for('pelanggan.pelanggan'))

    # GET: render form
    try:
        api = connect_remote(
            admin_data['ip_address'],
            admin_data['ppp_username'],
            admin_data['ppp_password']
        )
        profil_list = get_profiles_remote(api)
    except Exception as e:
        profil_list = []
        flash(f'Gagal mengambil profil Mikrotik: {e}', 'error')

    return render_template('edit_pelanggan.html', pelanggan=pelanggan_data, profil_list=profil_list)


@pelanggan_bp.route('/pelanggan/hapus/<int:id>', methods=['POST'])
def hapus_pelanggan(id):
    if not admin_login_required():
        return redirect(url_for('auth.login'))

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM pelanggan WHERE id = ? AND id_admin = ?", (id, session['admin_id']))
    pelanggan = c.fetchone()

    if not pelanggan:
        conn.close()
        flash('Pelanggan tidak ditemukan.', 'error')
        return redirect(url_for('pelanggan.pelanggan'))

    c.execute("SELECT ip_address, ppp_username, ppp_password FROM admin WHERE id_admin = ?", (session['admin_id'],))
    admin_data = c.fetchone()
    conn.close()

    if not admin_data or not admin_data['ip_address']:
        flash('Admin belum mengatur koneksi Mikrotik.', 'error')
        return redirect(url_for('pelanggan.pelanggan'))

    try:
        # Koneksi ke Mikrotik admin
        api = connect_remote(
            admin_data['ip_address'],
            admin_data['ppp_username'],
            admin_data['ppp_password']
        )

        # Hapus secret dari Mikrotik
        delete_secret_remote(api, pelanggan['ppp_username'])

    except Exception as e:
        flash(f'Gagal menghapus secret Mikrotik: {e}', 'error')
        # Tetap lanjut ke penghapusan data pelanggan

    try:
        # Hapus dari database
        conn = get_db()
        c = conn.cursor()
        c.execute("DELETE FROM pelanggan WHERE id = ? AND id_admin = ?", (id, session['admin_id']))
        conn.commit()
        conn.close()
        flash('Pelanggan berhasil dihapus.', 'success')
    except Exception as e:
        flash(f'Gagal menghapus pelanggan dari database: {e}', 'error')

    return redirect(url_for('pelanggan.pelanggan'))


@pelanggan_bp.route('/pelanggan/suspen/<int:id>', methods=['POST'])
def suspen_pelanggan(id):
    if not admin_login_required():
        return redirect(url_for('auth.login'))

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM pelanggan WHERE id = ? AND id_admin = ?", (id, session['admin_id']))
    pelanggan = c.fetchone()

    if not pelanggan:
        conn.close()
        flash('Pelanggan tidak ditemukan.', 'error')
        return redirect(url_for('pelanggan.pelanggan'))

    # Ambil kredensial Mikrotik admin
    c.execute("SELECT ip_address, ppp_username, ppp_password FROM admin WHERE id_admin = ?", (session['admin_id'],))
    admin_data = c.fetchone()
    conn.close()

    if not admin_data or not admin_data['ip_address']:
        flash('Admin belum mengatur koneksi Mikrotik.', 'error')
        return redirect(url_for('pelanggan.pelanggan'))

    try:
        # Koneksi ke Mikrotik
        api = connect_remote(
            admin_data['ip_address'],
            admin_data['ppp_username'],
            admin_data['ppp_password']
        )

        ppp = api.get_resource('/ppp/secret')
        secrets = ppp.get(name=pelanggan['ppp_username'])

        if not secrets:
            raise Exception("Secret tidak ditemukan di Mikrotik.")

        for s in secrets:
            id_key = s.get('.id') or s.get('id')
            if id_key:
                # Ubah profil ke 'isolir' tanpa mengubah comment
                ppp.set(id=id_key, profile='isolir')
                active = api.get_resource('/ppp/active')
                sessions = active.get(name=pelanggan['ppp_username'])
                for s in sessions:
                    id_key = s.get('.id') or s.get('id')
                    if id_key:
                        active.remove(id=id_key)

        # Update status pelanggan di database
        conn = get_db()
        c = conn.cursor()
        c.execute("UPDATE pelanggan SET status = 'suspen' WHERE id = ? AND id_admin = ?", (id, session['admin_id']))
        conn.commit()
        conn.close()

        flash('Pelanggan berhasil disuspen (profil diubah menjadi isolir).', 'success')

    except Exception as e:
        flash(f'Gagal menyuspen pelanggan: {e}', 'error')

    return redirect(url_for('pelanggan.pelanggan'))


@pelanggan_bp.route('/pelanggan/aktifkan/<int:id>', methods=['POST'])
def aktifkan_pelanggan(id):
    if not admin_login_required():
        return redirect(url_for('auth.login'))


    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM pelanggan WHERE id = ? AND id_admin = ?", (id, session['admin_id']))
    pelanggan = c.fetchone()

    if not pelanggan:
        conn.close()
        flash('Pelanggan tidak ditemukan.', 'error')
        return redirect(url_for('pelanggan.pelanggan'))

    c.execute("SELECT ip_address, ppp_username, ppp_password FROM admin WHERE id_admin = ?", (session['admin_id'],))
    admin_data = c.fetchone()
    conn.close()

    if not admin_data or not admin_data['ip_address']:
        flash('Admin belum mengatur koneksi Mikrotik.', 'error')
        return redirect(url_for('pelanggan.pelanggan'))

    try:
        api = connect_remote(
            admin_data['ip_address'],
            admin_data['ppp_username'],
            admin_data['ppp_password']
        )

        ppp = api.get_resource('/ppp/secret')
        secrets = ppp.get(name=pelanggan['ppp_username'])
        if not secrets:
            raise Exception("Secret tidak ditemukan di Mikrotik.")

        for s in secrets:
            id_key = s.get('.id') or s.get('id')
            comment = s.get('comment') or ''
            
            # Regex untuk ambil profil dari komentar
            match = re.search(r'Paket:\s*(\w+)', comment)
            profile_asli = match.group(1) if match else 'billing'  # fallback default

            if id_key:
                ppp.set(id=id_key, profile=profile_asli)
                active = api.get_resource('/ppp/active')
                sessions = active.get(name=pelanggan['ppp_username'])
                for s in sessions:
                    id_key = s.get('.id') or s.get('id')
                    if id_key:
                        active.remove(id=id_key)

        # Update status ke 'aktif' di DB
        conn = get_db()
        c = conn.cursor()
        c.execute("UPDATE pelanggan SET status = 'aktif' WHERE id = ? AND id_admin = ?", (id, session['admin_id']))
        conn.commit()
        conn.close()

        flash(f"Pelanggan telah diaktifkan kembali (profil: {profile_asli}).", 'success')

    except Exception as e:
        flash(f'Gagal mengaktifkan pelanggan: {e}', 'error')

    return redirect(url_for('pelanggan.pelanggan'))
